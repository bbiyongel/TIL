from pptx import Presentation
import papago_api_pre


prs = Presentation("./testppt.pptx")
sp = prs.slides[0]